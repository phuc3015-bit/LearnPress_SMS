<?php
/**
 * Plugin Name: LearnPress Stats Dashboard
 * Description: Hiển thị thống kê LearnPress
 * Version: 1.0
 * Author: Trọng Phúc
 */

function lp_total_courses()
{
    $args = array(
        'post_type' => 'lp_course',
        'post_status' => 'publish',
        'posts_per_page' => -1
    );

    $query = new WP_Query($args);
    return $query->found_posts;
}

function lp_total_students()
{
    global $wpdb;

    $table = $wpdb->prefix . 'learnpress_user_items';

    $count = $wpdb->get_var("
        SELECT COUNT(DISTINCT user_id)
        FROM $table
        WHERE item_type = 'lp_course'
    ");

    return $count;
}

function lp_total_completed_courses()
{
    global $wpdb;

    $table = $wpdb->prefix . 'learnpress_user_items';

    $count = $wpdb->get_var("
        SELECT COUNT(*)
        FROM $table
        WHERE status = 'completed'
        AND item_type = 'lp_course'
    ");

    return $count;
}

function lp_stats_dashboard_widget()
{
    wp_add_dashboard_widget(
        'lp_stats_widget',
        'LearnPress Stats',
        'lp_stats_display'
    );
}
add_action('wp_dashboard_setup', 'lp_stats_dashboard_widget');

function lp_stats_display()
{
    echo "<p><strong>Total Courses:</strong> " . lp_total_courses() . "</p>";
    echo "<p><strong>Total Students:</strong> " . lp_total_students() . "</p>";
    echo "<p><strong>Completed Courses:</strong> " . lp_total_completed_courses() . "</p>";
}

function lp_stats_shortcode()
{
    ob_start();
    ?>
<div>
    <h3>LearnPress Stats</h3>
    <p>Total Courses: <?php echo lp_total_courses(); ?></p>
    <p>Total Students: <?php echo lp_total_students(); ?></p>
    <p>Completed Courses: <?php echo lp_total_completed_courses(); ?></p>
</div>
<?php
    return ob_get_clean();
}
add_shortcode('lp_total_stats', 'lp_stats_shortcode');